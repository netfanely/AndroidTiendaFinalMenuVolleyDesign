<?php
	require_once("config.php");
	$caty = $_POST["caty"];
	//Esto incluye el contenido del archivo config.php
	$rs = mysqli_query($cn,
		"select * from productos where idcategoria=".$caty);
	$res=null;	
	while($row = mysqli_fetch_assoc($rs)){
		$res[] = array_map("utf8_encode",$row);
		//De esta manera los datos de cda fila
		//se colocan en un arreglo
	}
	echo json_encode(['data'=>$res]);
	//Se genera del arreglo un conjunto de resultados
	//en formato JSON
	$res=null;
	mysqli_close($cn);
?>