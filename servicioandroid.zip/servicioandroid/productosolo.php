<?php
	require_once("config.php");
 
	$cat = $_REQUEST["codproducto"];
	
	$rs = mysqli_query($cn,
		"select * from productos where idproducto=".$cat);
	while($row = mysqli_fetch_assoc($rs)){
		$res[] = array_map("utf8_encode",$row);
		//De esta manera los datos de cda fila
		//se colocan en un arreglo
	}
	echo json_encode($res);
	//Se genera del arreglo un conjunto de resultados
	//en formato JSON
	mysqli_close($cn);
?>