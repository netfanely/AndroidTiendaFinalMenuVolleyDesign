<?php
	header('Access-Control-Allow-Origin: *');  
	$cn = mysqli_connect("localhost","davidchu_empresa","empresa","davidchu_empresa");
	$rs = mysqli_query($cn,
		"select * from productos");
	$res=null;	
	while($row = mysqli_fetch_assoc($rs)){
		$res[] = array_map("utf8_encode",$row);
		//De esta manera los datos de cda fila
		//se colocan en un arreglo
	}
	echo json_encode($res);
	//Se genera del arreglo un conjunto de resultados
	//en formato JSON
	$res=null;
	mysqli_close($cn);
?>