<?php
 header('Access-Control-Allow-Origin: *');  
	$cn = mysqli_connect("localhost","davidchu_empresa","empresa","davidchu_empresa");
    //$cn = mysqli_connect("localhost","root","","empresa");
?>