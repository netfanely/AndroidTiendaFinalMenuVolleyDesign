<?php
	require_once("config.php");
	$nombre = $_REQUEST["nombre"];
	$descripcion = $_REQUEST["descripcion"];
	$rs = mysqli_query($cn,
		"insert into categorias (nombre,descripcion) values('".$nombre."','".$descripcion."')");
	echo mysqli_insert_id($cn); 
	mysqli_close($cn);
?>